<title>TRASHBLX IS IN REWRITE STAGE</title>
<center>
<h1>
trashblx is in rewrite stage
</h1>
</center>
<div>
<p>
Guess what, our vps got completly wiped and we lost literally everything :D
</p>
<p>
Of course i wouldnt be an idiot avoiding these cases just denying it, but im totally irresponsable person and we lost everything by a single sql injection.
</p>
<p>
😀
</p>
<a href="https://discord.gg/vaeSXduXae">Join our server to see our progress</a>
<span> 😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭😭 </span>
<p> small changes to the page: this hacker literally left the server acting like a 4chan user, which pissed me off. and btw i hope i dont see him EVER again </p>
</div>