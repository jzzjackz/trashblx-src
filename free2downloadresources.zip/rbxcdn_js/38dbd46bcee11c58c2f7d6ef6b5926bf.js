; // bundle: page___11b83bf8a61b0e8dffbbc77ad5099ed6_m
; // files: history.js/jquery.history.js, AdsHelper.js, Games/GamesDisplayShared.js, Games/GamesPageContainerBehavior.js, Games/GamesListBehavior.js, Accounts/EmailEntryModal.js, GenericConfirmation.js

; // history.js/jquery.history.js
typeof JSON != "object" && (JSON = {}),
    function() {
        "use strict";

        function i(n) {
            return n < 10 ? "0" + n : n
        }

        function f(n) {
            return o.lastIndex = 0, o.test(n) ? '"' + n.replace(o, function(n) {
                var t = s[n];
                return typeof t == "string" ? t : "\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
            }) + '"' : '"' + n + '"'
        }

        function r(i, e) {
            var s, l, h, a, v = n,
                c, o = e[i];
            o && typeof o == "object" && typeof o.toJSON == "function" && (o = o.toJSON(i)), typeof t == "function" && (o = t.call(e, i, o));
            switch (typeof o) {
                case "string":
                    return f(o);
                case "number":
                    return isFinite(o) ? String(o) : "null";
                case "boolean":
                case "null":
                    return String(o);
                case "object":
                    if (!o) return "null";
                    if (n += u, c = [], Object.prototype.toString.apply(o) === "[object Array]") {
                        for (a = o.length, s = 0; s < a; s += 1) c[s] = r(s, o) || "null";
                        return h = c.length === 0 ? "[]" : n ? "[\n" + n + c.join(",\n" + n) + "\n" + v + "]" : "[" + c.join(",") + "]", n = v, h
                    }
                    if (t && typeof t == "object")
                        for (a = t.length, s = 0; s < a; s += 1) typeof t[s] == "string" && (l = t[s], h = r(l, o), h && c.push(f(l) + (n ? ": " : ":") + h));
                    else
                        for (l in o) Object.prototype.hasOwnProperty.call(o, l) && (h = r(l, o), h && c.push(f(l) + (n ? ": " : ":") + h));
                    return h = c.length === 0 ? "{}" : n ? "{\n" + n + c.join(",\n" + n) + "\n" + v + "}" : "{" + c.join(",") + "}", n = v, h
            }
        }
        typeof Date.prototype.toJSON != "function" && (Date.prototype.toJSON = function() {
            return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + i(this.getUTCMonth() + 1) + "-" + i(this.getUTCDate()) + "T" + i(this.getUTCHours()) + ":" + i(this.getUTCMinutes()) + ":" + i(this.getUTCSeconds()) + "Z" : null
        }, String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function() {
            return this.valueOf()
        });
        var e = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
            o = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
            n, u, s = {
                "\b": "\\b",
                "\t": "\\t",
                "\n": "\\n",
                "\f": "\\f",
                "\r": "\\r",
                '"': '\\"',
                "\\": "\\\\"
            },
            t;
        typeof JSON.stringify != "function" && (JSON.stringify = function(i, f, e) {
            var o;
            if (n = "", u = "", typeof e == "number")
                for (o = 0; o < e; o += 1) u += " ";
            else typeof e == "string" && (u = e);
            if (t = f, !f || typeof f == "function" || typeof f == "object" && typeof f.length == "number") return r("", {
                "": i
            });
            throw new Error("JSON.stringify");
        }), typeof JSON.parse != "function" && (JSON.parse = function(n, t) {
            function r(n, i) {
                var f, e, u = n[i];
                if (u && typeof u == "object")
                    for (f in u) Object.prototype.hasOwnProperty.call(u, f) && (e = r(u, f), e !== undefined ? u[f] = e : delete u[f]);
                return t.call(n, i, u)
            }
            var i;
            if (n = String(n), e.lastIndex = 0, e.test(n) && (n = n.replace(e, function(n) {
                    return "\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
                })), /^[\],:{}\s]*$/.test(n.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) return i = eval("(" + n + ")"), typeof t == "function" ? r({
                "": i
            }, "") : i;
            throw new SyntaxError("JSON.parse");
        })
    }(),
    function(n, t) {
        "use strict";
        var i = n.History = n.History || {},
            r = n.jQuery;
        if (typeof i.Adapter != "undefined") throw new Error("History.js Adapter has already been loaded...");
        i.Adapter = {
            bind: function(n, t, i) {
                r(n).bind(t, i)
            },
            trigger: function(n, t, i) {
                r(n).trigger(t, i)
            },
            extractEventData: function(n, i, r) {
                return i && i.originalEvent && i.originalEvent[n] || r && r[n] || t
            },
            onDomLoad: function(n) {
                r(n)
            }
        }, typeof i.init != "undefined" && i.init()
    }(window),
    function(n) {
        "use strict";
        var r = n.document,
            f = n.setTimeout || f,
            e = n.clearTimeout || e,
            u = n.setInterval || u,
            i = n.History = n.History || {};
        if (typeof i.initHtml4 != "undefined") throw new Error("History.js HTML4 Support has already been loaded...");
        i.initHtml4 = function() {
            if (typeof i.initHtml4.initialized != "undefined") return !1;
            i.initHtml4.initialized = !0, i.enabled = !0, i.savedHashes = [], i.isLastHash = function(n) {
                var r = i.getHashByIndex(),
                    t;
                return t = n === r, t
            }, i.isHashEqual = function(n, t) {
                return n = encodeURIComponent(n).replace(/%25/g, "%"), t = encodeURIComponent(t).replace(/%25/g, "%"), n === t
            }, i.saveHash = function(n) {
                return i.isLastHash(n) ? !1 : (i.savedHashes.push(n), !0)
            }, i.getHashByIndex = function(n) {
                var t = null;
                return t = typeof n == "undefined" ? i.savedHashes[i.savedHashes.length - 1] : n < 0 ? i.savedHashes[i.savedHashes.length + n] : i.savedHashes[n], t
            }, i.discardedHashes = {}, i.discardedStates = {}, i.discardState = function(n, t, r) {
                var f = i.getHashByState(n),
                    u;
                return u = {
                    discardedState: n,
                    backState: r,
                    forwardState: t
                }, i.discardedStates[f] = u, !0
            }, i.discardHash = function(n, t, r) {
                var u = {
                    discardedHash: n,
                    backState: r,
                    forwardState: t
                };
                return i.discardedHashes[n] = u, !0
            }, i.discardedState = function(n) {
                var r = i.getHashByState(n),
                    t;
                return t = i.discardedStates[r] || !1, t
            }, i.discardedHash = function(n) {
                return i.discardedHashes[n] || !1
            }, i.recycleState = function(n) {
                var t = i.getHashByState(n);
                return i.discardedState(n) && delete i.discardedStates[t], !0
            }, i.emulated.hashChange && (i.hashChangeInit = function() {
                i.checkerFunction = null;
                var f = "",
                    s, t, e, o, h = Boolean(i.getHash());
                return i.isInternetExplorer() ? (s = "historyjs-iframe", t = r.createElement("iframe"), t.setAttribute("id", s), t.setAttribute("src", "#"), t.style.display = "none", r.body.appendChild(t), t.contentWindow.document.open(), t.contentWindow.document.close(), e = "", o = !1, i.checkerFunction = function() {
                    if (o) return !1;
                    o = !0;
                    var u = i.getHash(),
                        r = i.getHash(t.contentWindow.document);
                    return u !== f ? (f = u, r !== u && (e = r = u, t.contentWindow.document.open(), t.contentWindow.document.close(), t.contentWindow.document.location.hash = i.escapeHash(u)), i.Adapter.trigger(n, "hashchange")) : r !== e && (e = r, h && r === "" ? i.back() : i.setHash(r, !1)), o = !1, !0
                }) : i.checkerFunction = function() {
                    var t = i.getHash() || "";
                    return t !== f && (f = t, i.Adapter.trigger(n, "hashchange")), !0
                }, i.intervalList.push(u(i.checkerFunction, i.options.hashChangeInterval)), !0
            }, i.Adapter.onDomLoad(i.hashChangeInit)), i.emulated.pushState && (i.onHashChange = function(t) {
                var e = t && t.newURL || i.getLocationHref(),
                    u = i.getHashByUrl(e),
                    r = null,
                    o = null,
                    s = null,
                    f;
                return i.isLastHash(u) ? (i.busy(!1), !1) : (i.doubleCheckComplete(), i.saveHash(u), u && i.isTraditionalAnchor(u) ? (i.Adapter.trigger(n, "anchorchange"), i.busy(!1), !1) : (r = i.extractState(i.getFullUrl(u || i.getLocationHref()), !0), i.isLastSavedState(r) ? (i.busy(!1), !1) : (o = i.getHashByState(r), f = i.discardedState(r), f ? (i.getHashByIndex(-2) === i.getHashByState(f.forwardState) ? i.back(!1) : i.forward(!1), !1) : (i.pushState(r.data, r.title, encodeURI(r.url), !1), !0))))
            }, i.Adapter.bind(n, "hashchange", i.onHashChange), i.pushState = function(t, r, u, f) {
                if (u = encodeURI(u).replace(/%25/g, "%"), i.getHashByUrl(u)) throw new Error("History.js does not support states with fragment-identifiers (hashes/anchors).");
                if (f !== !1 && i.busy()) return i.pushQueue({
                    scope: i,
                    callback: i.pushState,
                    args: arguments,
                    queue: f
                }), !1;
                i.busy(!0);
                var e = i.createStateObject(t, r, u),
                    o = i.getHashByState(e),
                    s = i.getState(!1),
                    h = i.getHashByState(s),
                    c = i.getHash(),
                    l = i.expectedStateId == e.id;
                return i.storeState(e), i.expectedStateId = e.id, i.recycleState(e), i.setTitle(e), o === h ? (i.busy(!1), !1) : (i.saveState(e), l || i.Adapter.trigger(n, "statechange"), !i.isHashEqual(o, c) && !i.isHashEqual(o, i.getShortUrl(i.getLocationHref())) && i.setHash(o, !1), i.busy(!1), !0)
            }, i.replaceState = function(t, r, u, f) {
                if (u = encodeURI(u).replace(/%25/g, "%"), i.getHashByUrl(u)) throw new Error("History.js does not support states with fragment-identifiers (hashes/anchors).");
                if (f !== !1 && i.busy()) return i.pushQueue({
                    scope: i,
                    callback: i.replaceState,
                    args: arguments,
                    queue: f
                }), !1;
                i.busy(!0);
                var e = i.createStateObject(t, r, u),
                    s = i.getHashByState(e),
                    o = i.getState(!1),
                    h = i.getHashByState(o),
                    c = i.getStateByIndex(-2);
                return i.discardState(o, e, c), s === h ? (i.storeState(e), i.expectedStateId = e.id, i.recycleState(e), i.setTitle(e), i.saveState(e), i.Adapter.trigger(n, "statechange"), i.busy(!1)) : i.pushState(e.data, e.title, e.url, !1), !0
            }), i.emulated.pushState && i.getHash() && !i.emulated.hashChange && i.Adapter.onDomLoad(function() {
                i.Adapter.trigger(n, "hashchange")
            })
        }, typeof i.init != "undefined" && i.init()
    }(window),
    function(n, t) {
        "use strict";
        var e = n.console || t,
            r = n.document,
            o = n.navigator,
            f = n.sessionStorage || !1,
            h = n.setTimeout,
            c = n.clearTimeout,
            l = n.setInterval,
            a = n.clearInterval,
            u = n.JSON,
            v = n.alert,
            i = n.History = n.History || {},
            s = n.history;
        try {
            f.setItem("TEST", "1"), f.removeItem("TEST")
        } catch (y) {
            f = !1
        }
        if (u.stringify = u.stringify || u.encode, u.parse = u.parse || u.decode, typeof i.init != "undefined") throw new Error("History.js Core has already been loaded...");
        i.init = function() {
            return typeof i.Adapter == "undefined" ? !1 : (typeof i.initCore != "undefined" && i.initCore(), typeof i.initHtml4 != "undefined" && i.initHtml4(), !0)
        }, i.initCore = function() {
            if (typeof i.initCore.initialized != "undefined") return !1;
            if (i.initCore.initialized = !0, i.options = i.options || {}, i.options.hashChangeInterval = i.options.hashChangeInterval || 100, i.options.safariPollInterval = i.options.safariPollInterval || 500, i.options.doubleCheckInterval = i.options.doubleCheckInterval || 500, i.options.disableSuid = i.options.disableSuid || !1, i.options.storeInterval = i.options.storeInterval || 1e3, i.options.busyDelay = i.options.busyDelay || 250, i.options.debug = i.options.debug || !1, i.options.initialTitle = i.options.initialTitle || r.title, i.options.html4Mode = i.options.html4Mode || !1, i.options.delayInit = i.options.delayInit || !1, i.intervalList = [], i.clearAllIntervals = function() {
                    var n, t = i.intervalList;
                    if (typeof t != "undefined" && t !== null) {
                        for (n = 0; n < t.length; n++) a(t[n]);
                        i.intervalList = null
                    }
                }, i.debug = function() {
                    (i.options.debug || !1) && i.log.apply(i, arguments)
                }, i.log = function() {
                    var s = typeof e != "undefined" && typeof e.log != "undefined" && typeof e.log.apply != "undefined",
                        t = r.getElementById("log"),
                        n, f, h, o, i;
                    for (s ? (o = Array.prototype.slice.call(arguments), n = o.shift(), typeof e.debug != "undefined" ? e.debug.apply(e, [n, o]) : e.log.apply(e, [n, o])) : n = "\n" + arguments[0] + "\n", f = 1, h = arguments.length; f < h; ++f) {
                        if (i = arguments[f], typeof i == "object" && typeof u != "undefined") try {
                            i = u.stringify(i)
                        } catch (c) {}
                        n += "\n" + i + "\n"
                    }
                    return t ? (t.value += n + "\n-----\n", t.scrollTop = t.scrollHeight - t.clientHeight) : s || v(n), !0
                }, i.getInternetExplorerMajorVersion = function() {
                    return i.getInternetExplorerMajorVersion.cached = typeof i.getInternetExplorerMajorVersion.cached != "undefined" ? i.getInternetExplorerMajorVersion.cached : function() {
                        for (var n = 3, t = r.createElement("div"), i = t.getElementsByTagName("i");
                            (t.innerHTML = "<!--[if gt IE " + ++n + "]><i></i><![endif]-->") && i[0];);
                        return n > 4 ? n : !1
                    }()
                }, i.isInternetExplorer = function() {
                    return i.isInternetExplorer.cached = typeof i.isInternetExplorer.cached != "undefined" ? i.isInternetExplorer.cached : Boolean(i.getInternetExplorerMajorVersion())
                }, i.emulated = i.options.html4Mode ? {
                    pushState: !0,
                    hashChange: !0
                } : {
                    pushState: !Boolean(n.history && n.history.pushState && n.history.replaceState && !/ Mobile\/([1-7][a-z]|(8([abcde]|f(1[0-8]))))/i.test(o.userAgent) && !/AppleWebKit\/5([0-2]|3[0-2])/i.test(o.userAgent)),
                    hashChange: Boolean(!("onhashchange" in n || "onhashchange" in r) || i.isInternetExplorer() && i.getInternetExplorerMajorVersion() < 8)
                }, i.enabled = !i.emulated.pushState, i.bugs = {
                    setHash: Boolean(!i.emulated.pushState && o.vendor === "Apple Computer, Inc." && /AppleWebKit\/5([0-2]|3[0-3])/.test(o.userAgent)),
                    safariPoll: Boolean(!i.emulated.pushState && o.vendor === "Apple Computer, Inc." && /AppleWebKit\/5([0-2]|3[0-3])/.test(o.userAgent)),
                    ieDoubleCheck: Boolean(i.isInternetExplorer() && i.getInternetExplorerMajorVersion() < 8),
                    hashEscape: Boolean(i.isInternetExplorer() && i.getInternetExplorerMajorVersion() < 7)
                }, i.isEmptyObject = function(n) {
                    for (var t in n)
                        if (n.hasOwnProperty(t)) return !1;
                    return !0
                }, i.cloneObject = function(n) {
                    var i, t;
                    return n ? (i = u.stringify(n), t = u.parse(i)) : t = {}, t
                }, i.getRootUrl = function() {
                    var n = r.location.protocol + "//" + (r.location.hostname || r.location.host);
                    return (r.location.port || !1) && (n += ":" + r.location.port), n += "/", n
                }, i.getBaseHref = function() {
                    var i = r.getElementsByTagName("base"),
                        t = null,
                        n = "";
                    return i.length === 1 && (t = i[0], n = t.href.replace(/[^\/]+$/, "")), n = n.replace(/\/+$/, ""), n && (n += "/"), n
                }, i.getBaseUrl = function() {
                    return i.getBaseHref() || i.getBasePageUrl() || i.getRootUrl()
                }, i.getPageUrl = function() {
                    var r = i.getState(!1, !1),
                        t = (r || {}).url || i.getLocationHref(),
                        n;
                    return n = t.replace(/\/+$/, "").replace(/[^\/]+$/, function(n) {
                        return /\./.test(n) ? n : n + "/"
                    }), n
                }, i.getBasePageUrl = function() {
                    return i.getLocationHref().replace(/[#\?].*/, "").replace(/[^\/]+$/, function(n) {
                        return /[^\/]$/.test(n) ? "" : n
                    }).replace(/\/+$/, "") + "/"
                }, i.getFullUrl = function(n, t) {
                    var r = n,
                        u = n.substring(0, 1);
                    return t = typeof t == "undefined" ? !0 : t, /[a-z]+\:\/\//.test(n) || (r = u === "/" ? i.getRootUrl() + n.replace(/^\/+/, "") : u === "#" ? i.getPageUrl().replace(/#.*/, "") + n : u === "?" ? i.getPageUrl().replace(/[\?#].*/, "") + n : t ? i.getBaseUrl() + n.replace(/^(\.\/)+/, "") : i.getBasePageUrl() + n.replace(/^(\.\/)+/, "")), r.replace(/\#$/, "")
                }, i.getShortUrl = function(n) {
                    var t = n,
                        r = i.getBaseUrl(),
                        u = i.getRootUrl();
                    return i.emulated.pushState && (t = t.replace(r, "")), t = t.replace(u, "/"), i.isTraditionalAnchor(t) && (t = "./" + t), t = t.replace(/^(\.\/)+/g, "./").replace(/\#$/, ""), t
                }, i.getLocationHref = function(n) {
                    return n = n || r, n.URL === n.location.href ? n.location.href : n.location.href === decodeURIComponent(n.URL) ? n.URL : n.location.hash && decodeURIComponent(n.location.href.replace(/^[^#]+/, "")) === n.location.hash ? n.location.href : n.URL.indexOf("#") == -1 && n.location.href.indexOf("#") != -1 ? n.location.href : n.URL || n.location.href
                }, i.store = {}, i.idToState = i.idToState || {}, i.stateToId = i.stateToId || {}, i.urlToId = i.urlToId || {}, i.storedStates = i.storedStates || [], i.savedStates = i.savedStates || [], i.normalizeStore = function() {
                    i.store.idToState = i.store.idToState || {}, i.store.urlToId = i.store.urlToId || {}, i.store.stateToId = i.store.stateToId || {}
                }, i.getState = function(n, t) {
                    typeof n == "undefined" && (n = !0), typeof t == "undefined" && (t = !0);
                    var r = i.getLastSavedState();
                    return !r && t && (r = i.createStateObject()), n && (r = i.cloneObject(r), r.url = r.cleanUrl || r.url), r
                }, i.getIdByState = function(n) {
                    var t = i.extractId(n.url),
                        r;
                    if (!t)
                        if (r = i.getStateString(n), typeof i.stateToId[r] != "undefined") t = i.stateToId[r];
                        else if (typeof i.store.stateToId[r] != "undefined") t = i.store.stateToId[r];
                    else {
                        for (;;)
                            if (t = +new Date + String(Math.random()).replace(/\D/g, ""), typeof i.idToState[t] == "undefined" && typeof i.store.idToState[t] == "undefined") break;
                        i.stateToId[r] = t, i.idToState[t] = n
                    }
                    return t
                }, i.normalizeState = function(n) {
                    var t, r;
                    return (n && typeof n == "object" || (n = {}), typeof n.normalized != "undefined") ? n : (n.data && typeof n.data == "object" || (n.data = {}), t = {}, t.normalized = !0, t.title = n.title || "", t.url = i.getFullUrl(n.url ? n.url : i.getLocationHref()), t.hash = i.getShortUrl(t.url), t.data = i.cloneObject(n.data), t.id = i.getIdByState(t), t.cleanUrl = t.url.replace(/\??\&_suid.*/, ""), t.url = t.cleanUrl, r = !i.isEmptyObject(t.data), (t.title || r) && i.options.disableSuid !== !0 && (t.hash = i.getShortUrl(t.url).replace(/\??\&_suid.*/, ""), /\?/.test(t.hash) || (t.hash += "?"), t.hash += "&_suid=" + t.id), t.hashedUrl = i.getFullUrl(t.hash), (i.emulated.pushState || i.bugs.safariPoll) && i.hasUrlDuplicate(t) && (t.url = t.hashedUrl), t)
                }, i.createStateObject = function(n, t, r) {
                    var u = {
                        data: n,
                        title: t,
                        url: r
                    };
                    return u = i.normalizeState(u), u
                }, i.getStateById = function(n) {
                    n = String(n);
                    return i.idToState[n] || i.store.idToState[n] || t
                }, i.getStateString = function(n) {
                    var t, r, f;
                    return t = i.normalizeState(n), r = {
                        data: t.data,
                        title: n.title,
                        url: n.url
                    }, f = u.stringify(r), f
                }, i.getStateId = function(n) {
                    var t, r;
                    return t = i.normalizeState(n), r = t.id, r
                }, i.getHashByState = function(n) {
                    var t, r;
                    return t = i.normalizeState(n), r = t.hash, r
                }, i.extractId = function(n) {
                    var r, t, u, i;
                    return i = n.indexOf("#") != -1 ? n.split("#")[0] : n, t = /(.*)\&_suid=([0-9]+)$/.exec(i), u = t ? t[1] || n : n, r = t ? String(t[2] || "") : "", r || !1
                }, i.isTraditionalAnchor = function(n) {
                    return !/[\/\?\.]/.test(n)
                }, i.extractState = function(n, t) {
                    var r = null,
                        u, f;
                    return t = t || !1, u = i.extractId(n), u && (r = i.getStateById(u)), r || (f = i.getFullUrl(n), u = i.getIdByUrl(f) || !1, u && (r = i.getStateById(u)), !r && t && !i.isTraditionalAnchor(n) && (r = i.createStateObject(null, null, f))), r
                }, i.getIdByUrl = function(n) {
                    return i.urlToId[n] || i.store.urlToId[n] || t
                }, i.getLastSavedState = function() {
                    return i.savedStates[i.savedStates.length - 1] || t
                }, i.getLastStoredState = function() {
                    return i.storedStates[i.storedStates.length - 1] || t
                }, i.hasUrlDuplicate = function(n) {
                    var r = !1,
                        t;
                    return t = i.extractState(n.url), r = t && t.id !== n.id, r
                }, i.storeState = function(n) {
                    return i.urlToId[n.url] = n.id, i.storedStates.push(i.cloneObject(n)), n
                }, i.isLastSavedState = function(n) {
                    var t = !1,
                        r, u, f;
                    return i.savedStates.length && (r = n.id, u = i.getLastSavedState(), f = u.id, t = r === f), t
                }, i.saveState = function(n) {
                    return i.isLastSavedState(n) ? !1 : (i.savedStates.push(i.cloneObject(n)), !0)
                }, i.getStateByIndex = function(n) {
                    var t = null;
                    return t = typeof n == "undefined" ? i.savedStates[i.savedStates.length - 1] : n < 0 ? i.savedStates[i.savedStates.length + n] : i.savedStates[n], t
                }, i.getCurrentIndex = function() {
                    var n = null;
                    return n = i.savedStates.length < 1 ? 0 : i.savedStates.length - 1, n
                }, i.getHash = function(n) {
                    var r = i.getLocationHref(n),
                        t;
                    return t = i.getHashByUrl(r), t
                }, i.unescapeHash = function(n) {
                    var t = i.normalizeHash(n);
                    return t = decodeURIComponent(t), t
                }, i.normalizeHash = function(n) {
                    return n.replace(/[^#]*#/, "").replace(/#.*/, "")
                }, i.setHash = function(n, t) {
                    var u, f;
                    return t !== !1 && i.busy() ? (i.pushQueue({
                        scope: i,
                        callback: i.setHash,
                        args: arguments,
                        queue: t
                    }), !1) : (i.busy(!0), u = i.extractState(n, !0), u && !i.emulated.pushState ? i.pushState(u.data, u.title, u.url, !1) : i.getHash() !== n && (i.bugs.setHash ? (f = i.getPageUrl(), i.pushState(null, null, f + "#" + n, !1)) : r.location.hash = n), i)
                }, i.escapeHash = function(t) {
                    var r = i.normalizeHash(t);
                    return r = n.encodeURIComponent(r), i.bugs.hashEscape || (r = r.replace(/\%21/g, "!").replace(/\%26/g, "&").replace(/\%3D/g, "=").replace(/\%3F/g, "?")), r
                }, i.getHashByUrl = function(n) {
                    var t = String(n).replace(/([^#]*)#?([^#]*)#?(.*)/, "$2");
                    return t = i.unescapeHash(t), t
                }, i.setTitle = function(n) {
                    var t = n.title,
                        u;
                    t || (u = i.getStateByIndex(0), u && u.url === n.url && (t = u.title || i.options.initialTitle));
                    try {
                        r.getElementsByTagName("title")[0].innerHTML = t.replace("<", "&lt;").replace(">", "&gt;").replace(" & ", " &amp; ")
                    } catch (f) {}
                    return r.title = t, i
                }, i.queues = [], i.busy = function(n) {
                    if (typeof n != "undefined" ? i.busy.flag = n : typeof i.busy.flag == "undefined" && (i.busy.flag = !1), !i.busy.flag) {
                        c(i.busy.timeout);
                        var t = function() {
                            var n, r, u;
                            if (!i.busy.flag)
                                for (n = i.queues.length - 1; n >= 0; --n)(r = i.queues[n], r.length !== 0) && (u = r.shift(), i.fireQueueItem(u), i.busy.timeout = h(t, i.options.busyDelay))
                        };
                        i.busy.timeout = h(t, i.options.busyDelay)
                    }
                    return i.busy.flag
                }, i.busy.flag = !1, i.fireQueueItem = function(n) {
                    return n.callback.apply(n.scope || i, n.args || [])
                }, i.pushQueue = function(n) {
                    return i.queues[n.queue || 0] = i.queues[n.queue || 0] || [], i.queues[n.queue || 0].push(n), i
                }, i.queue = function(n, t) {
                    return typeof n == "function" && (n = {
                        callback: n
                    }), typeof t != "undefined" && (n.queue = t), i.busy() ? i.pushQueue(n) : i.fireQueueItem(n), i
                }, i.clearQueue = function() {
                    return i.busy.flag = !1, i.queues = [], i
                }, i.stateChanged = !1, i.doubleChecker = !1, i.doubleCheckComplete = function() {
                    return i.stateChanged = !0, i.doubleCheckClear(), i
                }, i.doubleCheckClear = function() {
                    return i.doubleChecker && (c(i.doubleChecker), i.doubleChecker = !1), i
                }, i.doubleCheck = function(n) {
                    return i.stateChanged = !1, i.doubleCheckClear(), i.bugs.ieDoubleCheck && (i.doubleChecker = h(function() {
                        return i.doubleCheckClear(), i.stateChanged || n(), !0
                    }, i.options.doubleCheckInterval)), i
                }, i.safariStatePoll = function() {
                    var r = i.extractState(i.getLocationHref()),
                        t;
                    if (!i.isLastSavedState(r)) return t = r, t || (t = i.createStateObject()), i.Adapter.trigger(n, "popstate"), i
                }, i.back = function(n) {
                    return n !== !1 && i.busy() ? (i.pushQueue({
                        scope: i,
                        callback: i.back,
                        args: arguments,
                        queue: n
                    }), !1) : (i.busy(!0), i.doubleCheck(function() {
                        i.back(!1)
                    }), s.go(-1), !0)
                }, i.forward = function(n) {
                    return n !== !1 && i.busy() ? (i.pushQueue({
                        scope: i,
                        callback: i.forward,
                        args: arguments,
                        queue: n
                    }), !1) : (i.busy(!0), i.doubleCheck(function() {
                        i.forward(!1)
                    }), s.go(1), !0)
                }, i.go = function(n, t) {
                    var r;
                    if (n > 0)
                        for (r = 1; r <= n; ++r) i.forward(t);
                    else {
                        if (!(n < 0)) throw new Error("History.go: History.go requires a positive or negative integer passed.");
                        for (r = -1; r >= n; --r) i.back(t)
                    }
                    return i
                }, i.emulated.pushState) {
                var p = function() {};
                i.pushState = i.pushState || p, i.replaceState = i.replaceState || p
            } else i.onPopState = function(t, r) {
                var e = !1,
                    u = !1,
                    o, f;
                return i.doubleCheckComplete(), o = i.getHash(), o ? (f = i.extractState(o || i.getLocationHref(), !0), f ? i.replaceState(f.data, f.title, f.url, !1) : (i.Adapter.trigger(n, "anchorchange"), i.busy(!1)), i.expectedStateId = !1, !1) : (e = i.Adapter.extractEventData("state", t, r) || !1, u = e ? i.getStateById(e) : i.expectedStateId ? i.getStateById(i.expectedStateId) : i.extractState(i.getLocationHref()), u || (u = i.createStateObject(null, null, i.getLocationHref())), i.expectedStateId = !1, i.isLastSavedState(u) ? (i.busy(!1), !1) : (i.storeState(u), i.saveState(u), i.setTitle(u), i.Adapter.trigger(n, "statechange"), i.busy(!1), !0))
            }, i.Adapter.bind(n, "popstate", i.onPopState), i.pushState = function(t, r, u, f) {
                if (i.getHashByUrl(u) && i.emulated.pushState) throw new Error("History.js does not support states with fragement-identifiers (hashes/anchors).");
                if (f !== !1 && i.busy()) return i.pushQueue({
                    scope: i,
                    callback: i.pushState,
                    args: arguments,
                    queue: f
                }), !1;
                i.busy(!0);
                var e = i.createStateObject(t, r, u);
                return i.isLastSavedState(e) ? i.busy(!1) : (i.storeState(e), i.expectedStateId = e.id, s.pushState(e.id, e.title, e.url), i.Adapter.trigger(n, "popstate")), !0
            }, i.replaceState = function(t, r, u, f) {
                if (i.getHashByUrl(u) && i.emulated.pushState) throw new Error("History.js does not support states with fragement-identifiers (hashes/anchors).");
                if (f !== !1 && i.busy()) return i.pushQueue({
                    scope: i,
                    callback: i.replaceState,
                    args: arguments,
                    queue: f
                }), !1;
                i.busy(!0);
                var e = i.createStateObject(t, r, u);
                return i.isLastSavedState(e) ? i.busy(!1) : (i.storeState(e), i.expectedStateId = e.id, s.replaceState(e.id, e.title, e.url), i.Adapter.trigger(n, "popstate")), !0
            };
            if (f) {
                try {
                    i.store = u.parse(f.getItem("History.store")) || {}
                } catch (w) {
                    i.store = {}
                }
                i.normalizeStore()
            } else i.store = {}, i.normalizeStore();
            i.Adapter.bind(n, "unload", i.clearAllIntervals), i.saveState(i.storeState(i.extractState(i.getLocationHref(), !0))), f && (i.onUnload = function() {
                var n, t, r;
                try {
                    n = u.parse(f.getItem("History.store")) || {}
                } catch (e) {
                    n = {}
                }
                n.idToState = n.idToState || {}, n.urlToId = n.urlToId || {}, n.stateToId = n.stateToId || {};
                for (t in i.idToState) i.idToState.hasOwnProperty(t) && (n.idToState[t] = i.idToState[t]);
                for (t in i.urlToId) i.urlToId.hasOwnProperty(t) && (n.urlToId[t] = i.urlToId[t]);
                for (t in i.stateToId) i.stateToId.hasOwnProperty(t) && (n.stateToId[t] = i.stateToId[t]);
                i.store = n, i.normalizeStore(), r = u.stringify(n);
                try {
                    f.setItem("History.store", r)
                } catch (o) {
                    if (o.code !== DOMException.QUOTA_EXCEEDED_ERR) throw o;
                    f.length && (f.removeItem("History.store"), f.setItem("History.store", r))
                }
            }, i.intervalList.push(l(i.onUnload, i.options.storeInterval)), i.Adapter.bind(n, "beforeunload", i.onUnload), i.Adapter.bind(n, "unload", i.onUnload)), i.emulated.pushState || (i.bugs.safariPoll && i.intervalList.push(l(i.safariStatePoll, i.options.safariPollInterval)), (o.vendor === "Apple Computer, Inc." || (o.appCodeName || "") === "Mozilla") && (i.Adapter.bind(n, "hashchange", function() {
                i.Adapter.trigger(n, "popstate")
            }), i.getHash() && i.Adapter.onDomLoad(function() {
                i.Adapter.trigger(n, "hashchange")
            })))
        }, (!i.options || !i.options.delayInit) && i.init()
    }(window);

; // AdsHelper.js
var Roblox = Roblox || {};
Roblox.AdsHelper = Roblox.AdsHelper || {}, Roblox.AdsHelper.AdRefresher = function() {
    var n = [];
    return this._Refresh = function() {
        var i, r, t;
        if (_isCreateNewAd()) {
            i = !1;
            for (id in n) {
                if (r = "#" + n[id] + " [data-js-adtype]", t = $(r), typeof t == "undefined") return;
                t.attr("data-js-adtype") === "iframead" ? _iFrameRefresh(t) : t.attr("data-js-adtype") === "gptAd" && (i = !0)
            }
            i && googletag.cmd.push(function() {
                googletag.pubads().refresh()
            }), Roblox.AdsHelper.DynamicAds.refreshOldAds()
        }
    }, this._iFrameRefresh = function(n) {
        var i = n.attr("src"),
            r, u, t;
        typeof i == "string" && (r = i.indexOf("?") < 0 ? "?" : "&", u = i + r + "nocache=" + (new Date).getMilliseconds().toString(), typeof n[0] != "undefined") && (t = n[0].contentDocument, t === undefined && (t = n[0].contentWindow), t.location.href !== "about:blank" && t.location.replace(u))
    }, this._isCreateNewAd = function() {
        return Roblox.GamesPageContainerBehavior.isCreateNewAd ? (Roblox.GamesPageContainerBehavior.isCreateNewAd = !1, Roblox.GamesPageContainerBehavior.setIntervalId && clearInterval(Roblox.GamesPageContainerBehavior.setIntervalId), Roblox.GamesPageContainerBehavior.setIntervalId = setInterval(function() {
            Roblox.GamesPageContainerBehavior.isCreateNewAd = !0
        }, Roblox.GamesPageContainerBehavior.adRefreshRateMilliSeconds), !0) : !1
    }, {
        registerAd: function(t) {
            n.push(t)
        },
        refreshAds: function() {
            _Refresh()
        }
    }
}(), Roblox.AdsHelper.DynamicAds = function() {
    function i() {
        return t
    }

    function n() {
        if (Roblox.GamesPageContainerBehavior && Roblox.GamesPageContainerBehavior.areAdsInSearchResults() && !Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && !Roblox.GamesPageContainerBehavior.isGutterAdsEnabled()) {
            var n = $(".in-game-search-ad").filter(".unpopulated");
            n.each(function(n, t) {
                var i = $(t),
                    u = i.attr("data-ad-slot"),
                    f = parseInt(i.attr("data-ad-width")),
                    e = parseInt(i.attr("data-ad-height")),
                    r = i.children(".ad-slot").attr("id");
                googletag.cmd.push(function() {
                    var n = googletag.defineSlot(u, [f, e], r).addService(googletag.pubads());
                    googletag.display(r), googletag.pubads().refresh([n])
                }), i.removeClass("unpopulated")
            })
        }
    }

    function r() {
        Roblox.GamesPageContainerBehavior && (Roblox.GamesPageContainerBehavior && (!Roblox.GamesPageContainerBehavior.areAdsInSearchResults() || Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode()) || ($(".overflow-visible .in-game-search-ad").each(function() {
            var i = $(this);
            i.children(".ad-slot").length > 0 && i.children(".ad-slot").html().trim() == "" && !i.hasClass("unpopulated") && (i.addClass("unpopulated").css("display", ""), i.children(".ad-slot").attr("id", "adx" + Math.floor(Math.random() * 1e8)))
        }), n()))
    }

    function u() {
        Roblox.GamesPageContainerBehavior && Roblox.GamesPageContainerBehavior.areAdsInSearchResults() && !Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() ? $("#ResponsiveWrapper").addClass("ads-in-game-search") : $("#ResponsiveWrapper").removeClass("ads-in-game-search")
    }
    var t = !0;
    return $(function() {
        Roblox.GamesPageContainerBehavior && Roblox.GamesPageContainerBehavior.areAdsInSearchResults() && googletag && (googletag.pubads && googletag.pubads() ? googletag.pubads().disableInitialLoad() : googletag.cmd.push(function() {
            googletag.pubads().disableInitialLoad()
        }))
    }), {
        isInitialPageLoad: i,
        populateNewAds: n,
        checkAdDisplayState: u,
        refreshOldAds: r
    }
}(), $(function() {
    function r(n, t, i) {
        i.html() == "" && (i.append(n), Roblox.AdsHelper.AdRefresher.refreshAds())
    }
    var v = 20,
        l = 970,
        c = 160,
        p = 728,
        h = l + c * 2 + 48 - v,
        y = l + c + 24 - v,
        a = "Skyscraper-Adp-Left",
        e = "Skyscraper-Adp-Right",
        s = "Leaderboard-Abp",
        i = $("#" + a),
        t = $("#" + e),
        f = $("#" + s),
        o = t.html(),
        u, w = f.html(),
        n;
    u = typeof RobloxAds != "undefined" && typeof RobloxAds.adLeftTemplate != "undefined" ? RobloxAds.adLeftTemplate : i.html(), n = $(window).width(), $(window).resize(function() {
        n = $(window).width(), n >= h ? (r(u, a, i), r(o, e, t)) : n < h && n >= y ? (r(o, e, t), i.html("")) : (t.html(""), i.html("")), n < p ? f.html("") : r(w, s, f)
    })
});

; // Games/GamesPageContainerBehavior.js
var Roblox = Roblox || {};
Roblox.GamesPageContainerBehavior = function() {
    function hf() {
        var t, i, r, u, f;
        $(".games-list-container").each(function() {
            t = $(this).attr("id"), i = $(this).data("sortfilter"), r = $(this).data("gamefilter"), u = $(this).data("minbclevel"), f = new Roblox.GamesListBehavior.GamesListObject(t, i, r, u), n.push(f)
        })
    }

    function b() {
        ci = !0;
        for (var i = 0; i < n.length; i++) n[i].isShown && (t ? n[i].numberOfRowsToOccupy > 1 ? n[i].populateGamesList(Math.max(eu, (p + 1) * n[i].numberOfRowsToOccupy), ou) : n[i].populateGamesList(ru, uu) : n[i].populateGamesList(ui));
        bi()
    }

    function kt() {
        var r = parseInt($($(".games-list-container")[0]).css("padding-left")),
            n = $("#GamesListsContainer").width(),
            i, t;
        n > r ? n -= r : n = 0, p = Math.floor(n / d), Roblox.GamesPageContainerBehavior.areAdsInSearchResults() && (i = $("<div class='ads-in-game-search' id='temp-remove'><div class='game-item'></div></div>"), $("#Footer").append(i), t = i.children(".game-item").width(), $("#temp-remove").remove(), t < d && (t = d), p = Math.floor(n / t))
    }

    function sf() {
        var u = -1,
            f = parseInt($("#GamesListsContainer").css("min-height")) || 0,
            e = Math.max($(window).height(), f) - (nu + (bt + tu) * s),
            o = Math.floor(e / et),
            r, i;
        for (h = t ? 1 : Math.max(1, Math.floor(2 * o / s)), r = !0, i = 0; i < n.length; i++) n[i].isShown && (t && r ? (n[i].numberOfRowsToOccupy = n[i].sortFilter == lu ? cu : h, r = !1) : n[i].numberOfRowsToOccupy = h, u = i)
    }

    function of() {
        for (var i = 0; i < n.length; i++) n[i].updateHeight(), !t && n[i].isShown ? n[i].showOverflow() : n[i].hideOverflow();
        $("#GamesPageLeftColumn").attr("data-searchstate") == "on" && n[n.length - 1].showOverflow()
    }

    function ef() {
        for (var t = 0; t < n.length; t++) $("#" + n[t].divId).css("top", "")
    }

    function ff() {
        for (var r = !0, u = 0, i, t = 0; t < n.length; t++) n[t].isShown && (r ? r = !1 : (i = (u++ + 1) * iu, $("#" + n[t].divId).css("top", "-" + i + "px")));
        i = s > 2 ? 160 : 110, $("#DivToHideOverflowFromLastGamesList").css("top", "-" + i + "px")
    }

    function uf() {
        $(".games-list-container").each(function(n, t) {
            var i = $(t).attr("id"),
                r = $("#" + i).find(".game-item").length,
                u = $("#" + i).find(".game-item").outerWidth(!0),
                f = $("#" + i).find(".horizontally-scrollable").css("left");
            ii($(t), u, r, f)
        })
    }

    function vi(n, t, i, r) {
        var f = n / t,
            u;
        return f = isNaN(f) ? 0 : Math.floor(f), r = !r || isNaN(parseInt(r)) ? 0 : Math.abs(parseInt(r)), u = r / t, u = isNaN(u) ? 0 : Math.floor(u), i - u <= f
    }

    function ii(n, t, i, r) {
        var u = vi(n.width(), t, i, r);
        n.find(".scroller.next").toggleClass("hidden", u)
    }

    function k() {
        lt(), kt(), sf(), of()
    }

    function rf() {
        var n, t;
        $("div.filter select").each(function() {
            $(this).change(function() {
                n = $(this).attr("id"), t = $(this).val(), t && n && (g(n, t), tt || (u = !0, ut(), u = !1), b())
            })
        })
    }

    function g(n, t) {
        tf(), it && $("html").hide();
        switch (n) {
            case "SortFilter":
                nf(t), du(t), $("#SortFilter").val(t);
                break;
            case "TimeFilter":
                ku(t), $("#TimeFilter").val(t);
                break;
            case "GenreFilter":
                bu(t), $("#GenreFilter").val(t)
        }
        it && setTimeout(function() {
            $("html").show()
        }, ct)
    }

    function tf() {
        for (var t = 0; t < n.length; t++) n[t].resetStartIndex()
    }

    function nf(n) {
        $.inArray(n, gi) !== -1 ? ($("#TimeFilter").prop("disabled", !0), ti("disabled")) : ($("#TimeFilter").prop("disabled", !1), ti("enabled")), $.inArray(n, li) !== -1 ? $("#GenreFilter").prop("disabled", !0) : $("#GenreFilter").prop("disabled", !1)
    }

    function gu() {
        $("#TimeFilter option").each(function(n, t) {
            f[n] = {
                label: t.label,
                value: t.value
            }
        })
    }

    function ti(n) {
        var t = $("#TimeFilter"),
            i;
        t.find("option").remove();
        switch (n) {
            case "enabled":
                for (i = 1; i < f.length; i++) t.append('<option value="' + f[i].value + '">' + f[i].label + "</option>");
                t.val(fi), t.attr("data-default", fi);
                break;
            case "disabled":
                t.append('<option value="' + f[0].value + '">' + f[0].label + "</option>"), t.val(0), t.attr("data-default", 0)
        }
    }

    function du(n) {
        wr(), ef(), fr(n), ff(), k(), $("#GamesPageRightColumnSidebar").length > 0 && (n !== "default" || $("#GamesPageRightColumnSidebar").hasClass(v) || ($("#GamesPageRightColumnSidebar").removeClass(), $("#GamesPageRightColumnSidebar").addClass(v)))
    }

    function ku(n) {
        dr(n)
    }

    function bu(n) {
        wu(n)
    }

    function wu(t) {
        for (var i = 0; i < n.length; i++) n[i].genreId = t
    }

    function dr(t) {
        for (var i = 0; i < n.length; i++) n[i].timeFilter = t
    }

    function vu() {
        $("#SortFilter").val($("#SortFilter").data("default")), $("#TimeFilter").val($("#TimeFilter").data("default")), $("#GenreFilter").val($("#GenreFilter").data("default"))
    }

    function br() {
        var n = {};
        e && l !== "" ? Roblox.GamesDisplayShared.updateURLFromSearchState() : (n = wi(), a.replaceState(n.urlStateObject, Roblox.GamesPageContainerBehavior.Resources.pageTitle, "?" + n.urlStateString))
    }

    function ut() {
        var n = wi();
        a.pushState(n.urlStateObject, Roblox.GamesPageContainerBehavior.Resources.pageTitle, "?" + n.urlStateString)
    }

    function wi() {
        var i = "",
            u = {},
            r;
        if ($("div.filter select").each(function() {
                filterType = $(this).attr("id"), selectedVal = $(this).val(), selectedVal && filterType && !$(this).prop("disabled") && (i += (i === "" ? "" : "&") + filterType + "=" + selectedVal, u[filterType] = selectedVal)
            }), !t)
            for (r = 0; r < n.length; r++) n[r].isShown && n[r].minBCLevel === 1 && (i += (i === "" ? "" : "&") + "BC=1"), u.BC = 1;
        return {
            urlStateString: i,
            urlStateObject: u
        }
    }

    function ki(n) {
        if (!u) {
            if (n.hasOwnProperty("keyword")) $("#searchbox").val(n.keyword), $("#SearchResultsContainer .search-query-text").text() !== n.keyword && $("#GamesPageSearch .SearchIconButton").click();
            else {
                Roblox.GamesDisplayShared.toggleSearch("reset"), tt = !0;
                for (var t in n) g(t, n[t]);
                tt = !1, b()
            }
            Roblox.AdsHelper.DynamicAds.checkAdDisplayState(), Roblox.AdsHelper.DynamicAds.refreshOldAds()
        }
    }

    function ir() {
        $(document).on("GuttersHidden", function() {
            c && (c = !1, Roblox.AdsHelper.AdRefresher.registerAd("GamePageAdDiv1"), Roblox.AdsHelper.AdRefresher.registerAd("GamePageAdDiv2"), i = $("#LeftGutterAdContainer"), r = $("#RightGutterAdContainer"), $("#GamesPageLeftColumn").css("margin", "0 345px 0 10px"), i.hide(), r.hide(), $("#GutterAdStyles").remove(), $("#GamesPageRightColumnSidebar").html("<iframe id='GamesRightColumn' src='/games/rightcolumn' scrolling='no' frameBorder='0' style='height:550px;width:330px;border:0px;overflow:hidden'></iframe>"))
        })
    }

    function tr() {
        $(document).on("FilmStripHidden", function() {
            $("#GamePageAdDiv3").hide(), $("#GamesPageRightColumnSidebar").html("<iframe id='GamesRightColumn' src='/games/rightcolumn' scrolling='no' frameBorder='0' style='height:550px;width:330px;border:0px;overflow:hidden'></iframe>")
        })
    }

    function lt() {
        var u, t, f;
        if (c) {
            u = Roblox.FixedUI.getWindowWidth(), Roblox.GamesPageContainerBehavior.IsUserLoggedIn || (u >= oi ? $("#LeftGutterAdContainer").css("margin-left", 11) : $("#LeftGutterAdContainer").css("margin-left", 0), $("#LeftGutterAdContainer").css("z-index", 2), $("#RightGutterAdContainer").css("z-index", 5)), i = $("#LeftGutterAdContainer"), r = $("#RightGutterAdContainer"), w = i.width();
            var e = $(".rbx-left-col"),
                o = e && e.css("display") === "block",
                n = $("body").width();
            Roblox.GamesPageContainerBehavior.IsUserLoggedIn && o && u >= oi && (n = n - hu), n <= ot ? ($("#GamesPageLeftColumn").css("margin", "0"), i.hide(), r.hide()) : (t = rr(n), f = t - w, i.css("left", f + "px"), r.css("right", f + "px"), i.show(), r.show(), $("#GamesPageLeftColumn").css("margin", "0 " + (t + 10) + "px 0 " + (t + 10) + "px"))
        }
    }

    function rr(n) {
        return n > ot + 20 + 2 * w ? w : Math.max((n - 20 - ot) / 2, 0)
    }

    function wt(t) {
        for (var i = 0; i < n.length; i++)
            if (n[i].divId === "GamesListContainer" + t) return n[i];
        return null
    }

    function wr() {
        for (var t = 0; t < n.length; t++) n[t].hide();
        s = 0
    }

    function fr(n) {
        if (Roblox.GamesPageContainerBehavior.FilterValueToGamesListsIdSuffixMapping.hasOwnProperty(n)) {
            t = !0;
            for (var i = 0; i < Roblox.GamesPageContainerBehavior.FilterValueToGamesListsIdSuffixMapping[n].length; i++) ni(Roblox.GamesPageContainerBehavior.FilterValueToGamesListsIdSuffixMapping[n][i], t);
            $("#DivToHideOverflowFromLastGamesList, #Footer").removeClass("hidden")
        } else t = !1, ni(n, t), $("#DivToHideOverflowFromLastGamesList, #Footer").addClass("hidden")
    }

    function ni(n, t) {
        var i = wt(n);
        i && (i.show(t), s++)
    }

    function er() {
        o = $(window).width(), y = $(window).height(), $("#GamesPageRightColumnSidebar").length > 0 && (ei = $("#GamesPageRightColumnSidebar").position().top)
    }

    function dt() {
        return t || !1
    }

    function or() {
        return vt
    }

    function pt() {
        return p
    }

    function sr() {
        return h
    }

    function hr() {
        return ai
    }

    function vr() {
        return ri
    }

    function yr() {
        return Roblox.GamesPageContainerBehavior.DeviceTypeId
    }

    function at() {
        Roblox.GamesDisplayShared.toggleSearch("reset"), g("SortFilter", "default"), u = !0, ut(), u = !1, b()
    }

    function ur() {
        var n = $(window).width() || 0;
        return n >= 980 ? "move-with-window-stick-right" : "move-with-window-min-left"
    }

    function si() {
        var i = $(this).closest(".games-list-container").attr("id") || "",
            t = i.replace("GamesListContainer", ""),
            r = wt(t);
        return r != null && (g("SortFilter", t), u = !0, ut(), u = !1, b()), Roblox.AdsHelper.DynamicAds.checkAdDisplayState(), !1
    }

    function pi() {
        for (var t = 0; t < n.length; t++) n[t].isShown && n[t].appendToGamesList(n[t].numberOfGamesToFetch)
    }

    function pr(n) {
        return $.inArray(n, su) !== -1 ? "https://www.roblox.ink/games/moreresultsuncached" : "https://www.roblox.ink/games/moreresultscached"
    }

    function bi() {
        Roblox.AdsHelper.AdRefresher.refreshAds();
        var n = $("#GamesRightColumn")[0];
        n != null && n.contentWindow.Roblox.RightColumnBehavior.refreshAds()
    }

    function ar() {
        return t
    }

    function lr(n) {
        t = n
    }

    function cr() {
        return nt ? nt : 0
    }

    function yt(n) {
        nt = n
    }

    function gt(n, t, i) {
        if (dt() || !Roblox.GamesPageContainerBehavior.areAdsInSearchResults()) return 0;
        var r = Math.ceil(i / n);
        return r * t
    }

    function nr(n) {
        yt(gt(et, pt() - 1, n))
    }

    function pu() {
        var n = $(".overflow-visible .in-game-search-ad").last(),
            t = 0;
        return n.length > 0 && n.hasClass("ad-order-even") && (t = 1), t
    }

    function lf() {
        return $("#BodyWrapper").hasClass("gutter-ads-enabled")
    }
    var kr = 300,
        gr = 50,
        d = 202,
        nu = 240,
        bt = 40,
        tu = 40,
        et = 168,
        iu = 55,
        ru = 12,
        uu = 12,
        ui = 60,
        fu = 60,
        eu = 40,
        ou = 30,
        ot = 970,
        gi = [],
        li = [],
        su = [5, 6, 10],
        hu = 175,
        oi = 1480,
        fi = 2,
        n = [],
        s = 0,
        p, h, cu = 4,
        lu = 16,
        o, y, ei, v, t, hi = 0,
        a = window.History,
        ci = !1,
        tt = !1,
        u = !1,
        yi = !1,
        c = !1,
        i, r, w, au, di = 400,
        rt = !1,
        ai = !1,
        ri = !1,
        af = 3,
        it, ct, f = [],
        e = !1,
        l = "",
        ht = 40,
        vt = !1,
        nt = 0,
        yu = 1326,
        cf = 800,
        ft = 0,
        st;
    return $(function() {
        document.title = Roblox.GamesPageContainerBehavior.Resources.pageTitle, $("#SortFilter [data-hidetimefilter]").each(function(n, t) {
            gi.push($(t).val())
        }), $("#SortFilter [data-hidegenrefilter]").each(function(n, t) {
            li.push($(t).val())
        }), ai = $("#FiltersAndSort").data("defaultweeklyratings"), ri = $("#FiltersAndSort").data("defaulttoppaidtoweekly"), au = $("div.nav-container"), hf(), $("#GamesPageRightColumnSidebar").length > 0 && (v = $("#GamesPageRightColumnSidebar").attr("class")), e = $("#ResponsiveWrapper").data("gamessearchonpage"), vt = $("#ResponsiveWrapper").data("adsingamesearchresultsenabled"), l = $("#searchbox").data("default"), e && l !== "" && $("#searchbox").val(l), it = $("div[data-worseperformanceenabled]").data("worseperformanceenabled") === "True", ct = Number($("div[data-worseperformancedelay]").data("worseperformancedelay")), rf(), a.Adapter.bind(window, "statechange", function() {
            ki(a.getState().data)
        }), vu(), gu(), br(), Roblox.GamesDisplayShared.hookUpEvents(), er(), i = $("#LeftGutterAdContainer"), r = $("#RightGutterAdContainer"), c = i.length !== 0, yi = $("#TopAbpContainer").length !== 0, $(".games-filter-resetter").click(at), $(".games-filter-changer").click(si), c ? (Roblox.AdsHelper.AdRefresher.registerAd("LeftGutterAdContainer"), Roblox.AdsHelper.AdRefresher.registerAd("RightGutterAdContainer")) : (Roblox.AdsHelper.AdRefresher.registerAd("GamePageAdDiv1"), Roblox.AdsHelper.AdRefresher.registerAd("GamePageAdDiv2"), Roblox.AdsHelper.AdRefresher.registerAd("GamePageAdDiv3")), yi && Roblox.AdsHelper.AdRefresher.registerAd("TopAbpContainer"), ci || ki(a.getState().data), k();
        $(".scroller, .scroller .arrow, .scroller .arrow img").on("dblclick", function() {
            return window.getSelection ? window.getSelection().removeAllRanges() : document.selection && document.selection.empty(), !1
        });
        ir(), tr(), e && $("#SearchResultsContainer").addClass("can-search"), e && l !== "" && Roblox.GamesDisplayShared.searchOnPage(ht), Roblox.AdsHelper.DynamicAds.checkAdDisplayState()
    }), $(window).resize(function() {
        var i = $(window).width(),
            r = $(window).height();
        uf(), i > o || r > y ? setTimeout(function() {
            if (k(), !t) {
                for (var u = 0; u < n.length; u++) n[u].isShown && n[u].appendToGamesList(n[u].numberOfGamesToFetch);
                i >= 980 && $("#GamesPageRightColumnSidebar.move-with-window-min-left").toggleClass("move-with-window-min-left move-with-window-stick-right")
            }
            o = i, y = r
        }, kr) : (i < o || r < y) && setTimeout(function() {
            i < o && lt(), t ? k() : i < 980 && $("#GamesPageRightColumnSidebar.move-with-window-stick-right").toggleClass("move-with-window-min-left move-with-window-stick-right"), o = i, y = r
        }, gr), di = r / 2
    }), $(window).scroll(function() {
        var n = $(window).scrollTop(),
            i, r;
        t || (i = ur(), r = $("#GamesPageLeftColumn").data("searchstate"), n + 60 > ei ? $("#GamesPageRightColumnSidebar").hasClass(i) || ($("#GamesPageRightColumnSidebar").removeClass(), $("#GamesPageRightColumnSidebar").addClass(i)) : $("#GamesPageRightColumnSidebar").hasClass(v) || ($("#GamesPageRightColumnSidebar").removeClass(), $("#GamesPageRightColumnSidebar").addClass(v)), n > hi && (!t || e && r == "on") && $(window).scrollTop() >= $(document).height() - $(window).height() - di && (r == "on" ? Roblox.GamesDisplayShared.moreSearchResults() : pi())), hi = n
    }), st = null, {
        GamesListHeaderHeight: bt,
        RowHeightIncludingPadding: et,
        ColumnWidthIncludingPadding: d,
        MaxNumberOfGamesToFetchInHScrollMode: fu,
        NumberOfGamesToFetchInVScrollMode: ui,
        numGamesToFetchOnSearch: ht,
        initialAdHeight: yu,
        subsequentAdHeight: cf,
        getNumberOfColumns: pt,
        getNumberOfRows: sr,
        handleGamesFilterChangerClick: si,
        handleGamesFilterResetClick: at,
        isInHorizontalScrollMode: dt,
        getURLBasedOnSortFilter: pr,
        isTopRatedDefaultToWeeklyEnabled: hr,
        isTopPaidDefaultToWeeklyEnabled: vr,
        getDeviceTypeId: yr,
        toggleCarouselButtons: ii,
        doesNextButtonFitContainer: vi,
        getMultipleGamesListsDisplayedState: ar,
        setMultipleGamesListsDisplayedState: lr,
        refreshAds: bi,
        loadMoreGames: pi,
        areAdsInSearchResults: or,
        getAdSpan: cr,
        setAdSpan: yt,
        setAdSpanFromHeight: nr,
        calcAdSpan: gt,
        calcAdAlignment: pu,
        isGutterAdsEnabled: lf,
        calculateNumberOfColumns: kt
    }
}();

; // Games/GamesListBehavior.js
var Roblox = Roblox || {};
Roblox.GamesListBehavior = {}, Roblox.GamesListBehavior.ExtraHeightToShowHover = 50, Roblox.GamesListBehavior.MaxNumberOfGamesToLoadPerRequest = 200, Roblox.GamesListBehavior.NumberOfGamesToAppendInHScrollMode = 12, Roblox.GamesListBehavior.RefreshAdsInGamesPageEnabled = !1, Roblox.GamesListBehavior.GamesListObject = function(n, t, i, r) {
    this.divId = n, this.isShown = !1, this.sortFilter = t, this.gameFilter = i, this.timeFilter = 0, this.minBCLevel = r, this.genreId = 1, this.numberOfRowsToOccupy = 0, this.numberOfGamesToFetch = 0, this.numberOfGamesOnScreen = 0, this.startIndex = 0, this.jqxhr = null, this.reachedHorizontalScrollMax = !1, this.numberOfGamesOnLastRow = 0, this.attachHoverHandlers(), this.attachScrollHandlers();
    $("#" + this.divId).on("click", ".games-filter-changer", Roblox.GamesPageContainerBehavior.handleGamesFilterChangerClick)
}, Roblox.GamesListBehavior.GamesListObject.prototype = {
    populateGamesList: function(n, t) {
        var i = this,
            u, f;
        i.jqxhr && jqxhr.abort(), Roblox.AdsHelper.DynamicAds.checkAdDisplayState(), Roblox.GamesPageContainerBehavior.calculateNumberOfColumns();
        var e = Roblox.GamesPageContainerBehavior.getURLBasedOnSortFilter(i.sortFilter),
            r = Roblox.GamesPageContainerBehavior.getNumberOfColumns(),
            o = Roblox.GamesPageContainerBehavior.getNumberOfRows();
        i.numberOfGamesToFetch = Math.min(n, Roblox.GamesListBehavior.MaxNumberOfGamesToLoadPerRequest), i.numberOfGamesOnLastRow = 0, i.timeFilter = i.getDefaultTimeFilterForSortFilter(i.sortFilter, i.timeFilter), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && i.numberOfRowsToOccupy > 1 ? $("#" + i.divId + " .scroller").remove() : (i.reachedHorizontalScrollMax = !1, $("#" + i.divId + " .scroller.next").removeClass("hidden")), u = Roblox.GamesPageContainerBehavior.isGutterAdsEnabled() ? Roblox.GamesPageContainerBehavior.subsequentAdHeight : Roblox.GamesPageContainerBehavior.initialAdHeight, Roblox.GamesPageContainerBehavior.setAdSpanFromHeight(u), f = {
            SortFilter: i.sortFilter,
            TimeFilter: i.timeFilter,
            GenreID: i.genreId,
            GameFilter: i.gameFilter,
            MinBCLevel: i.minBCLevel,
            StartRows: i.startIndex,
            MaxRows: i.numberOfGamesToFetch,
            IsUserLoggedIn: Roblox.GamesPageContainerBehavior.IsUserLoggedIn,
            NumberOfRowsToOccupy: i.numberOfRowsToOccupy,
            NumberOfColumns: r,
            IsInHorizontalScrollMode: Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode(),
            DeviceTypeId: Roblox.GamesPageContainerBehavior.getDeviceTypeId(),
            AdSpan: Roblox.GamesPageContainerBehavior.getAdSpan(),
            AdAlignment: 0
        }, i.showLoadingIndicator(), i.jqxhr = $.get(e, f, function(n) {
            var e, u, f, s;
            i.jqxhr = null, e = $("<div></div>").append(n), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() || i.hideExtraGames(e), Roblox.AdsHelper.DynamicAds.checkAdDisplayState(), u = $("#" + i.divId + " .games-list"), $(u).find(".game-item,.games-list-column, .in-game-search-ad").remove(), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && (i.numberOfRowsToOccupy < 2 ? u = $("#" + i.divId + " .horizontally-scrollable") : (u.append('<div class = "multi-rows"></div>'), u = $(u).find(".multi-rows"))), u.append(e.html()), i.numberOfGamesOnScreen = $(u).find(".game-item").length, Roblox.AdsHelper.DynamicAds.populateNewAds(), i.hideLoadingIndicator(), !Roblox.GamesPageContainerBehavior.getMultipleGamesListsDisplayedState() && r * o > Roblox.GamesPageContainerBehavior.NumberOfGamesToFetchInVScrollMode && Roblox.GamesPageContainerBehavior.loadMoreGames(), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && (f = $("#" + i.divId + " .horizontally-scrollable"), f.length > 0 && ($(f).css("left", 0), $(f).siblings(".scroller.prev").addClass("hidden")), s = $(u).find(".game-item").outerWidth(!0), Roblox.GamesPageContainerBehavior.toggleCarouselButtons($("#" + i.divId), s, i.numberOfGamesOnScreen, 0), i.noMoreGamesToLoad = i.numberOfGamesOnScreen < i.numberOfGamesToFetch, !i.noMoreGamesToLoad && t > 0 && (i.jqxhr = null, i.appendToGamesList(t))), Roblox.AdsHelper.DynamicAds.refreshOldAds()
        })
    },
    appendToGamesList: function(n) {
        var t, i, r;
        this.jqxhr || Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && this.reachedHorizontalScrollMax || (t = this, i = Roblox.GamesPageContainerBehavior.getURLBasedOnSortFilter(t.sortFilter), n = Math.min(n, Roblox.GamesListBehavior.MaxNumberOfGamesToLoadPerRequest), t.timeFilter = t.getDefaultTimeFilterForSortFilter(t.sortFilter, t.timeFilter), t.unhideGames(), Roblox.GamesPageContainerBehavior.setAdSpanFromHeight(Roblox.GamesPageContainerBehavior.subsequentAdHeight), r = {
            SortFilter: t.sortFilter,
            TimeFilter: t.timeFilter,
            GenreID: t.genreId,
            GameFilter: t.gameFilter,
            MinBCLevel: t.minBCLevel,
            StartRows: t.numberOfGamesOnScreen,
            MaxRows: n,
            IsUserLoggedIn: Roblox.GamesPageContainerBehavior.IsUserLoggedIn,
            NumberOfRowsToOccupy: t.numberOfRowsToOccupy,
            NumberOfColumns: Roblox.GamesPageContainerBehavior.getNumberOfColumns(),
            IsInHorizontalScrollMode: Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode(),
            DeviceTypeId: Roblox.GamesPageContainerBehavior.getDeviceTypeId(),
            AdSpan: Roblox.GamesPageContainerBehavior.getAdSpan(),
            AdAlignment: Roblox.GamesPageContainerBehavior.calcAdAlignment()
        }, t.showLoadingIndicator(), t.jqxhr = $.get(i, r, function(i) {
            var u, r;
            t.jqxhr = null, u = $("<div></div>").append(i), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() || t.hideExtraGames(u), r = $("#" + t.divId + " .games-list"), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && (r = t.numberOfRowsToOccupy > 1 ? $("#" + t.divId + " .multi-rows") : $("#" + t.divId + " .horizontally-scrollable")), r.append(u.html()), t.numberOfGamesOnScreen = $(r).find(".game-item").length, Roblox.AdsHelper.DynamicAds.populateNewAds(), Roblox.AdsHelper.DynamicAds.refreshOldAds(), t.hideLoadingIndicator(), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && (t.noMoreGamesToLoad = $(i).find(".game-item").length < n, t.reachedHorizontalScrollMax = t.numberOfGamesOnScreen > Roblox.GamesPageContainerBehavior.MaxNumberOfGamesToFetchInHScrollMode)
        }))
    },
    getDefaultTimeFilterForSortFilter: function(n, t) {
        var r = $("#TimeFilter").attr("data-default"),
            i = Roblox.GamesPageContainerBehavior,
            u = i.isTopRatedDefaultToWeeklyEnabled(),
            f = i.isTopPaidDefaultToWeeklyEnabled(),
            e = i.isInHorizontalScrollMode();
        return r == 0 ? t = 0 : t == 0 && (t = r), e && (u && n == 11 || f && n == 9 || n == 16) && (t = 2), t
    },
    show: function(n) {
        n && $("#" + this.divId + " .games-list").find(".game-item,.games-list-column,.in-game-search-ad").remove(), this.isShown = !0, $("#" + this.divId).removeClass("hidden"), n ? $("#" + this.divId + " .show-in-multiview-mode-only").removeClass("hidden") : $("#" + this.divId + " .show-in-multiview-mode-only").addClass("hidden")
    },
    hide: function() {
        this.isShown = !1, this.numberOfRowsToOccupy = 0, $("#" + this.divId).addClass("hidden")
    },
    updateHeight: function() {
        $("#" + this.divId).height(this.maxHeight()), Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() && $("#" + this.divId + " .horizontally-scrollable").height(this.numberOfRowsToOccupy * Roblox.GamesPageContainerBehavior.RowHeightIncludingPadding)
    },
    showOverflow: function() {
        $("#" + this.divId).removeClass("overflow-hidden"), $("#" + this.divId).addClass("overflow-visible")
    },
    hideOverflow: function() {
        $("#" + this.divId).removeClass("overflow-visible"), $("#" + this.divId).addClass("overflow-hidden")
    },
    attachHoverHandlers: function() {
        $("#" + this.divId).on({
            mouseenter: function() {
                $(this).children(".show-on-hover-only").removeClass("hidden"), $(this).siblings(".hover-shown").show()
            },
            mouseleave: function() {
                $(this).children(".show-on-hover-only").addClass("hidden"), $(this).siblings(".hover-shown").hide()
            }
        }, ".always-shown")
    },
    attachScrollHandlers: function() {
        var n = this;
        $("#" + this.divId).on("click", ".scroller", function() {
            var t = this,
                i = "next";
            t && (t.className.indexOf("prev") !== -1 && (i = "prev"), n.handleHorizontalScroll(i))
        })
    },
    handleHorizontalScroll: function(n) {
        var i = $("#" + this.divId + " .horizontally-scrollable"),
            r, t, u;
        i.length > 0 && ($(i).stop("", !0, !0), r = parseInt($(i).css("left")) || 0, r = this.getClosestColumnBoundary(r), n === "prev" ? (t = r + this.getLeftBoundaryOfLastVisibleColumn(), t = Math.min(t, 0), $("#" + this.divId + " .scroller.next").removeClass("hidden")) : (t = r - this.getLeftBoundaryOfLastVisibleColumn(), this.appendToGamesList(Roblox.GamesListBehavior.NumberOfGamesToAppendInHScrollMode), (this.noMoreGamesToLoad || this.reachedHorizontalScrollMax) && !this.isAvailableWidthFullyOccupied(t) && $("#" + this.divId + " .scroller.next").addClass("hidden")), $(i).animate({
            left: t + "px"
        }), Roblox.GamesListBehavior.RefreshAdsInGamesPageEnabled && Roblox.GamesPageContainerBehavior.refreshAds(), u = t < 0, u ? $(i).siblings(".scroller.prev").removeClass("hidden") : $(i).siblings(".scroller.prev").addClass("hidden"))
    },
    showLoadingIndicator: function() {
        Roblox.GamesPageContainerBehavior.isInHorizontalScrollMode() || $("#" + this.divId).css("cursor", "wait")
    },
    hideLoadingIndicator: function() {
        $("#" + this.divId).css("cursor", "auto")
    },
    resetStartIndex: function() {
        this.startIndex = 0, $("#" + this.divId + " .previous").addClass("disabled"), $("#" + this.divId + " .next").removeClass("disabled")
    },
    hideExtraGames: function(n) {
        var i = $(n).find(".game-item").length,
            t = Roblox.GamesPageContainerBehavior.getNumberOfColumns() * this.numberOfRowsToOccupy - this.numberOfGamesOnLastRow,
            r = 0;
        i > t && $(n).find(".game-item").each(function() {
            r++ >= t && $(this).addClass("hidden")
        })
    },
    maxHeight: function() {
        var n = 0;
        return this.isShown && (n += this.numberOfRowsToOccupy * Roblox.GamesPageContainerBehavior.RowHeightIncludingPadding, n += Roblox.GamesPageContainerBehavior.GamesListHeaderHeight, n += Roblox.GamesListBehavior.ExtraHeightToShowHover), n
    },
    unhideGames: function() {
        var n = $("#" + this.divId + " .game-item.hidden").length;
        this.numberOfGamesOnLastRow = n % Roblox.GamesPageContainerBehavior.getNumberOfColumns(), $("#" + this.divId + " .game-item.hidden").each(function() {
            $(this).removeClass("hidden")
        })
    },
    getClosestColumnBoundary: function(n) {
        var t = Math.abs(n % Roblox.GamesPageContainerBehavior.ColumnWidthIncludingPadding);
        return n + t
    },
    getLeftBoundaryOfLastVisibleColumn: function() {
        var n = $("#" + this.divId + " .games-list").width(),
            t = Math.floor(n / Roblox.GamesPageContainerBehavior.ColumnWidthIncludingPadding);
        return t * Roblox.GamesPageContainerBehavior.ColumnWidthIncludingPadding
    },
    isAvailableWidthFullyOccupied: function(n) {
        var t = $("#" + this.divId + " .games-list").width(),
            i = Math.ceil(t / Roblox.GamesPageContainerBehavior.ColumnWidthIncludingPadding),
            r = Math.abs(n / Roblox.GamesPageContainerBehavior.ColumnWidthIncludingPadding);
        return this.numberOfGamesOnScreen >= r + i
    }
};

; // Accounts/EmailEntryModal.js
typeof Roblox.EmailEntryModal == "undefined" && (Roblox.EmailEntryModal = function() {
    function t(t, i) {
        var r = $("div#EmailEntryModal").filter(":first");
        r.length == 0 && (r = $("<div id='EmailEntryModal' class='modalPopup'><div class='Message'></div></div>")), t ? r.find("div.Message").html(t) : $(i).appendTo(r.find("div.Message")), r.modal(n)
    }
    var n = {
        overlayClose: !0,
        escClose: !0,
        opacity: 80,
        overlayCss: {
            backgroundColor: "#000"
        }
    };
    return {
        open: t
    }
}());

; // GenericConfirmation.js
typeof Roblox == "undefined" && (Roblox = {}), typeof Roblox.GenericConfirmation == "undefined" && (Roblox.GenericConfirmation = function() {
    function v(f) {
        var a = {
                titleText: "",
                bodyContent: "",
                footerText: "",
                acceptText: Roblox.Resources.GenericConfirmation.yes,
                declineText: Roblox.Resources.GenericConfirmation.No,
                acceptColor: r,
                declineColor: u,
                xToCancel: !1,
                onAccept: function() {
                    return !1
                },
                onDecline: function() {
                    return !1
                },
                onCancel: function() {
                    return !1
                },
                imageUrl: null,
                allowHtmlContentInBody: !1,
                allowHtmlContentInFooter: !1,
                dismissable: !0,
                fieldValidationRequired: !1,
                onOpenCallback: function() {}
            },
            e, o, s, l;
        f = $.extend({}, a, f), i.overlayClose = f.dismissable, i.escClose = f.dismissable, e = $(n), e.html(f.acceptText + "<span class='btn-text'>" + f.acceptText + "</span>"), e.attr("class", "btn-large " + f.acceptColor), e.unbind(), e.bind("click", function() {
            return c(e) ? !1 : (f.fieldValidationRequired ? d(f.onAccept) : h(f.onAccept), !1)
        }), o = $(t), o.html(f.declineText + "<span class='btn-text'>" + f.declineText + "</span>"), o.attr("class", "btn-large " + f.declineColor), o.unbind(), o.bind("click", function() {
            return c(o) ? !1 : (h(f.onDecline), !1)
        }), $('[data-modal-handle="confirmation"] div.Title').text(f.titleText), s = $("[data-modal-handle='confirmation']"), f.imageUrl == null ? s.addClass("noImage") : (s.find("img.GenericModalImage").attr("src", f.imageUrl), s.removeClass("noImage")), f.allowHtmlContentInBody ? $("[data-modal-handle='confirmation'] div.Message").html(f.bodyContent) : $("[data-modal-handle='confirmation'] div.Message").text(f.bodyContent), $.trim(f.footerText) == "" ? $('[data-modal-handle="confirmation"] div.ConfirmationModalFooter').hide() : $('[data-modal-handle="confirmation"] div.ConfirmationModalFooter').show(), f.allowHtmlContentInFooter ? $('[data-modal-handle="confirmation"] div.ConfirmationModalFooter').html(f.footerText) : $('[data-modal-handle="confirmation"] div.ConfirmationModalFooter').text(f.footerText), $("[data-modal-handle='confirmation']").modal(i), l = $("a.genericmodal-close"), l.unbind(), l.bind("click", function() {
            return h(f.onCancel), !1
        }), f.xToCancel || l.hide(), f.onOpenCallback()
    }

    function a(n) {
        n.hasClass(u) ? n.addClass(o) : n.hasClass(l) ? n.addClass(f) : n.hasClass(r) && n.addClass(e)
    }

    function c(n) {
        return n.hasClass(e) || n.hasClass(o) || n.hasClass(f) ? !0 : !1
    }

    function y() {
        var i = $(n),
            r = $(t);
        a(i), a(r)
    }

    function p() {
        var u = $(n),
            r = $(t),
            i = e + " " + o + " " + f;
        u.removeClass(i), r.removeClass(i)
    }

    function w() {
        var t = $(n);
        t.click()
    }

    function b() {
        var n = $(t);
        n.click()
    }

    function s(n) {
        typeof n != "undefined" ? $.modal.close(n) : $.modal.close()
    }

    function h(n) {
        s(), typeof n == "function" && n()
    }

    function d(n) {
        if (typeof n == "function") {
            var t = n();
            if (t !== "undefined" && t == !1) return !1
        }
        s()
    }
    var l = "btn-primary",
        r = "btn-neutral",
        u = "btn-negative",
        f = "btn-disabled-primary",
        e = "btn-disabled-neutral",
        o = "btn-disabled-negative",
        k = "btn-none",
        n = "#roblox-confirm-btn",
        t = "#roblox-decline-btn",
        i = {
            overlayClose: !0,
            escClose: !0,
            opacity: 80,
            overlayCss: {
                backgroundColor: "#000"
            }
        };
    return {
        open: v,
        close: s,
        disableButtons: y,
        enableButtons: p,
        clickYes: w,
        clickNo: b,
        green: l,
        blue: r,
        gray: u,
        none: k
    }
}());