var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

;// bundle: Widgets___HierarchicalDropdown___1146ea256b786219861473ee73475a5d_m
;// files: modules/Widgets/HierarchicalDropdown.js

;// modules/Widgets/HierarchicalDropdown.js
Roblox.define("Widgets.HierarchicalDropdown",[],function(){function n(n){var t=n.width();n.find("li").each(function(n,i){i=$(i),i.outerWidth()>t&&(t=i.outerWidth())}),n.find("li").each(function(n,i){i=$(i),i.width()<t&&i.width(t)})}$(function(){var i=0,r=0,t=$(".roblox-hierarchicaldropdown"),f=t.find("li"),u=t.find("li ul"),e=t.find("li ul[hover=true]");u.mouseover(function(){$(this).attr("hover","true")}),u.mouseout(function(){$(this).attr("hover","false")}),f.mouseover(function(){var i=$(this).data("delay"),f;i!="ignore"&&e.length==0&&($(this).attr("hover","true"),i!="never"&&(r==1||i=="always")?window.setTimeout(function(){if(e.length==0){var i=t.find("li[hover=true] ul");u.hide(),i.length!=0&&(i.show(),n(i))}},1e3):(u.hide(),f=$(this).find("ul"),f.show(),n(f)))}),f.mouseout(function(){$(this).removeAttr("hover")}),t.mouseleave(function(){window.setTimeout(function(){u.hide()},100),i=0,r=0}),t.mousemove(function(n){var t=i;i=n.pageX,(t==i||t==0)&&(r=0),r=t<i?1:-1})})});


}
/*
     FILE ARCHIVED ON 20:42:59 Apr 20, 2015 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 19:14:51 Apr 26, 2024.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.599
  exclusion.robots: 0.065
  exclusion.robots.policy: 0.055
  cdx.remote: 0.054
  esindex: 0.01
  LoadShardBlock: 73.796 (3)
  PetaboxLoader3.datanode: 87.538 (5)
  PetaboxLoader3.resolve: 98.021 (3)
  load_resource: 127.081 (2)
*/