var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

;// bundle: Pages___Catalog___64f248f2e590d7cff2798d4779e6206b_m
;// files: modules/Pages/Catalog.js

;// modules/Pages/Catalog.js
Roblox.define("Pages.Catalog",["Widgets.ItemImage","Widgets.HierarchicalDropdown"],function(n){function c(t,f){n.populate(),i=t,i.TotalNumberOfPages=f,i.EmptyStringSearchEnabled=$("#catalog").data("empty-search-enabled"),a(),$(".Paging_Input").keypress(function(n){n.which=="13"&&v()}),$("#keywordTextbox").keypress(function(n){if(n.which=="13")return e(),!1}),$("#creatorTextbox").keypress(function(n){if(n.which=="13")return o(),!1}),$(".pxInput").keypress(function(n){if(n.which=="13")return s(),!1}),$("select#categoriesForKeyword").change(function(){i.EmptyStringSearchEnabled&&e()});var c=$("#legendcontent").css("display")!="none";$("#legendheader").click(function(){c?($("#legendcontent").hide(),$(this).removeClass("expanded")):($("#legendcontent").show(),$(this).addClass("expanded")),c=!c}),$(".assetTypeFilter").click(function(){var t=$(this).data("category"),f=$(this).data("keepfilters"),n;return t!==undefined&&(f!==undefined?u({types:!0,category:!0}):h(),i.Category=t),n=$(this).data("types"),n!==undefined&&(i.Subcategory=n),r(!1),!1}),$(".gearFilter").click(function(){var n=$(this).data("types"),t=$(this).data("category");t!==undefined?(h(),i.Category=t,n!="All"&&(i.Gears=n)):i.Gears=n=="All"?null:n,r(!1)}),$(".genreFilter").click(function(){return i.Genres=$("input.genreFilter:checked").map(function(){return $(this).data("genreid")}).get().toString().split(","),i.Genres==""&&(i.Genres=null),r(!1),!0}),$(".creatorFilter").click(function(){var n=$(this).data("creatorid");i.CreatorID=n,r(!1)}),$(".breadCrumbFilter").click(function(){var n=$(this).data("filter");switch(n){case"category":u({types:!0,gears:!0,genres:!0,creator:!0,prices:!0,keyword:!0});break;case"subcategory":u({gears:!0,genres:!0,creator:!0,prices:!0,keyword:!0});break;case"gears":u({genres:!0,creator:!0,prices:!0,keyword:!0});break;case"genres":u({creator:!0,prices:!0,keyword:!0});break;case"creator":u({prices:!0,keyword:!0});break;case"px":u({keyword:!0})}r(!1)}),$(".priceFilter").click(function(){i.CurrencyType=$(this).data("currencytype"),r(!1)}),$("#submitCreatorButton").click(o),$("#creatorTextbox").focus(function(){$(this).val()=="Name"&&$(this).val(""),$(this).removeClass("Watermark")}),$("#creatorTextbox").blur(function(){$(this).val()==""&&($(this).val("Name"),$(this).addClass("Watermark"))}),$(".pxInput").focus(function(){($(this).val()=="Min"||$(this).val()=="Max")&&$(this).val(""),$(this).removeClass("Watermark")}),$(".pxInput").blur(function(){var n=$(this).data("watermarktext");$(this).val()==""&&($(this).val(n),$(this).addClass("Watermark"))}),$("#submitPxButton").click(s),$("a#submitSearchButton").click(e),$("select#SortMain").change(function(){i.SortType=document.getElementById("SortMain").value,r(!1)}),$("select#SortAggregation").change(function(){i.SortAggregation=document.getElementById("SortAggregation").value,i.SortCurrency=null,r(!1)}),$("select#SortCurrency").change(function(){i.SortCurrency=document.getElementById("SortCurrency").value,i.SortAggregation=null,r(!1)}),$("#includeNotForSaleCheckbox").change(function(){i.IncludeNotForSale=$(this).prop("checked"),r(!1)}),$("#pagingprevious").click(function(){$(this).hasClass("disabled")||(i.PageNumber--,i.PageNumber>=1&&r(!0))}),$("#pagingnext").click(function(){$(this).hasClass("disabled")||(i.PageNumber++,r(!0))})}function o(){f=document.getElementById("creatorTextbox").value,f!=""&&(i.CreatorID=null,r(!1))}function s(){i.CurrencyType=$("#submitPxButton").data("currencytype");var n=document.getElementById("pxMinInput").value,t=document.getElementById("pxMaxInput").value;n!=""&&parseInt(n)>0&&(i.PxMin=n),t!=""&&t!="0"&&(i.PxMax=t),r(!1)}function e(){if(i.Keyword=encodeURIComponent(document.getElementById("keywordTextbox").value),i.Keyword==""&&!i.EmptyStringSearchEnabled)return!1;var n=$("#categoriesForKeyword").val();return n=="Custom"?u({genres:!0,creator:!0,prices:!0,sorts:!0}):(u({category:!0,types:!0,gears:!0,genres:!0,creator:!0,prices:!0}),i.Category=n),r(!1),!1}function l(){u({genres:!0}),r(!1)}function h(){u({category:!0,types:!0,gears:!0,genres:!0,creator:!0,prices:!0,keyword:!0})}function u(n){n.category&&(i.Category=""),n.types&&(i.Subcategory=""),n.gears&&(i.Gears=null),n.genres&&(i.Genres=null),n.creator&&(i.CreatorID=null),n.prices&&(i.CurrencyType=null,i.PxMin=null,i.PxMax=null,i.IncludeNotForSale=null),n.keyword&&(i.Keyword=null),n.sorts&&(i.SortType=null,i.SortAggregation=null,i.SortCurrency=null)}function a(){i.PageNumber==1?$("#pagingprevious").addClass("disabled"):i.PageNumber==i.TotalNumberOfPages&&$("#pagingnext").addClass("disabled")}function v(){i.PageNumber=Math.round($("input.Paging_Input").val()),i.PageNumber>=1&&(i.PageNumber>i.TotalNumberOfPages&&(i.PageNumber=i.TotalNumberOfPages),r(!0))}function r(n){var t="/catalog/browse.aspx?",u,e=!1,r;if(Roblox.CatalogValues&&(Roblox.CatalogValues.CatalogContentsUrl&&Roblox.CatalogValues.ContainerID&&(u=$("#"+Roblox.CatalogValues.ContainerID),u.length!==0&&(t=Roblox.CatalogValues.CatalogContentsUrl+"?",e=!0)),Roblox.CatalogValues.CatalogContext!==undefined&&(t+="CatalogContext="+Roblox.CatalogValues.CatalogContext+"&")),i.Subcategory!=null&&i.Subcategory!=""&&(t+="Subcategory="+i.Subcategory+"&"),i.Gears!=null&&(t+="Gears="+i.Gears+"&"),i.Genres!=null)for(r=0;r<i.Genres.length;r++)t+="Genres="+i.Genres[r]+"&";i.CreatorID!=null&&i.CreatorID!=0?t+="CreatorID="+i.CreatorID+"&":f!=null&&(t+="CreatorName="+f+"&"),i.Keyword!=null&&(t+="Keyword="+i.Keyword+"&"),i.CurrencyType!=null&&(t+="CurrencyType="+i.CurrencyType+"&"),i.PxMin!=null&&(t+="pxMin="+i.PxMin+"&"),i.PxMax!=null&&(t+="pxMax="+i.PxMax+"&"),i.SortType!=null&&(t+="SortType="+i.SortType+"&"),i.SortAggregation!=null&&(t+="SortAggregation="+i.SortAggregation+"&"),i.SortCurrency!=null&&(t+="SortCurrency="+i.SortCurrency+"&"),n&&i.PageNumber>=0&&(t+="PageNumber="+i.PageNumber+"&"),i.IncludeNotForSale!=null&&$("#includeNotForSaleCheckbox").length!=0&&(t+="IncludeNotForSale="+i.IncludeNotForSale+"&"),t+="LegendExpanded="+($("#legendcontent").css("display")!="none").toString()+"&",t+="Category="+i.Category,e?Roblox.CatalogShared.LoadCatalogAjax(t,null,u):window.location=t}var i,f;return{ClearGenres:l,pagestate:i,init:c}});


}
/*
     FILE ARCHIVED ON 20:42:49 Apr 20, 2015 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 19:14:43 Apr 26, 2024.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.8
  exclusion.robots: 0.074
  exclusion.robots.policy: 0.065
  cdx.remote: 0.059
  esindex: 0.009
  LoadShardBlock: 56.504 (3)
  PetaboxLoader3.datanode: 70.49 (5)
  load_resource: 253.526 (2)
  PetaboxLoader3.resolve: 176.894 (2)
*/