;// bundle: Pagelets___BestFriends___b5520cc9d4705238e8405c93a383ffa0_m
;// files: modules/Pagelets/BestFriends.js

;// modules/Pagelets/BestFriends.js
Roblox.define("Pagelets.BestFriends",["../CSS/My/BestFriends.css","jQuery","Widgets.AvatarImage"],function(n,t){function i(i){n.get("/my/best-friends",function(r){n(i).html(r),t.populate()})}return{init:i}});