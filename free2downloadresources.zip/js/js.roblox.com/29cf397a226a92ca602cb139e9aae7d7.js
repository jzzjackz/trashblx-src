;// bundle: jQuery___f96d183221b7e5fc88ce682603a50c3a_m
;// files: modules/jQuery.js

;// modules/jQuery.js
if(typeof jQuery!="undefined"&&jQuery.fn.jquery!="1.7.2")var conflict=!0;Roblox.define("jQuery","/js/jquery/jquery-1.7.2.min.js",function(){return conflict?jQuery.noConflict(!0):jQuery});