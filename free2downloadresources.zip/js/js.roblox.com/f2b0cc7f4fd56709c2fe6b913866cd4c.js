;// bundle: nonLoggedIn___3b6c5c0583dff5fa7201f664ebf09b81_m
;// files: jquery.ba-postmessage.min.js, parentFrameLogin.js

;// jquery.ba-postmessage.min.js
/*
 * jQuery postMessage - v0.5 - 9/11/2009
 * http://benalman.com/projects/jquery-postmessage-plugin/
 * 
 * Copyright (c) 2009 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function($){var g,d,j=1,a,b=this,f=!1,h="postMessage",e="addEventListener",c,i=b[h]&&!$.browser.opera;$[h]=function(k,l,m){if(!l){return}k=typeof k==="string"?k:$.param(k);m=m||parent;if(i){m[h](k,l.replace(/([^:]+:\/\/[^\/]+).*/,"$1"))}else{if(l){m.location=l.replace(/#.*$/,"")+"#"+(+new Date)+(j++)+"&"+k}}};$.receiveMessage=c=function(l,m,k){if(i){if(l){a&&c();a=function(n){if((typeof m==="string"&&n.origin!==m)||($.isFunction(m)&&m(n.origin)===f)){return f}l(n)}}if(b[e]){b[l?e:"removeEventListener"]("message",a,f)}else{b[l?"attachEvent":"detachEvent"]("onmessage",a)}}else{g&&clearInterval(g);g=null;if(l){k=typeof m==="number"?m:typeof k==="number"?k:100;g=setInterval(function(){var o=document.location.hash,n=/^#?\d+&/;if(o!==d&&n.test(o)){d=o;l({data:o.replace(n,"")})}},k)}}}})(jQuery);

;// parentFrameLogin.js
$(function(){var n=!1,t,i;$("#header-login").click(function(i){return n=!n,t(n),$("#iFrameLogin").toggle(),$("#header-login").toggleClass("active"),i.stopPropagation(),!1}),$("#headerLogin").click(function(i){return n=!n,t(n),$("#iFrameLogin").toggle(),$("#headerLogin").toggleClass("active"),i.stopPropagation(),!1}),$(document).click(function(){n&&($("#header-login").removeClass("active"),$("#headerLogin").removeClass("active"),$("#iFrameLogin").hide(),n=!1)}),t=function(n){$(".IframeAdHide").each(function(){$(this).height()==90&&$(this).width()==728&&(n?$(this).css("visibility","hidden"):$(this).css("visibility","visible"))})},i=function(n){var t,i;n.indexOf("resize")!=-1&&(t=n.split(","),$("#iFrameLogin").css({height:t[1]})),n.indexOf("fbRegister")!=-1&&(t=n.split("^"),i="&fbname="+encodeURIComponent(t[1])+"&fbem="+encodeURIComponent(t[2])+"&fbdt="+encodeURIComponent(t[3]),window.location.href="../Login/Default.aspx?iFrameFacebookSync=true"+i)},$.receiveMessage(function(n){i(n.data)}),$("#header-login-wrapper").data("display-opened")=="True"&&($("#header-login").addClass("active"),$("#iFrameLogin").css("display","block"))});